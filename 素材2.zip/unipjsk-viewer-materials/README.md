# unipjsk-viewer-materials

unipjsk（viewer.unipjsk.com / WebSekai）の動的譜面ビューアー再現用の素材セット。
2026-11-26 整理版。ファイル名はすべて ASCII、日本語名や分解文字（NFD）は使っていない。

## フォルダ構造

```
unipjsk-viewer-materials/
  README.md            このファイル
  MANIFEST.md          全ファイルの一覧（サイズ・MD5付き）
  assets/
    notes/
      skin01-notes.png            ノーツアトラス skin01（1644x1472）
      skin01-notes.txt            skin01 の切り取り座標表（36種＋同時押しライン）
      skin01-guide.png            ガイドノーツ skin01（244x224）
      skin01-long.png             ロング帯 skin01（306x16）
      skin02-notes.png            ノーツアトラス skin02（1644x1472）
      skin02-guide.png            ガイドノーツ skin02（244x224）
      skin02-long.png             ロング帯 skin02（306x16）
      individual/
        custom01/                 個別ノーツPNG 36種（Notes 01）
        custom02/                 個別ノーツPNG 36種（Notes 02 / 3周年）
    effects/
      effect.png                  エフェクトアトラス（1024x1024）
      effect-transform.txt        エフェクト用スプライト変換表
      fx/profile0/                fx JSON 25種（プロファイル0）
      fx/profile1/                fx JSON 25種（プロファイル1）
    stage/
      stage.png                   ステージ（2048x1176）
      bg_stage.png                2Dモード用ステージアトラス（2048x2840）
      stage.txt                   bg_stage.png の切り取り表
      default.png                 既定ステージ背景（2048x2048）
      chart2.png                  既定背景
    lanes/
      lane-1920x1080.png          レーン（1920x1080）
      lane-2048x1176.png          レーン全面版（2048x1176）
      background-overlay-2048.png 背景オーバーレイ（2048x2048）
      long-note-line.txt          ロング帯の4区分（skin01-long.png 用）
      touch-line.txt              タッチラインの4区分（skin01-guide.png 用）
    sounds/
      se_live_*.mp3               打撃音 13種
```

## 対応表（.txt と画像のペア）

| 座標表 | 対象の画像 | 備考 |
|---|---|---|
| assets/notes/skin01-notes.txt | assets/notes/skin01-notes.png | 36種の矩形は個別PNGの実寸と一致（例：notes_0.png = 354x186） |
| assets/lanes/long-note-line.txt | assets/notes/skin01-long.png | 306x16 を 306x2 の4区分に分ける |
| assets/lanes/touch-line.txt | assets/notes/skin01-guide.png | 244x224 内の1pxライン4区分 |
| assets/stage/stage.txt | assets/stage/bg_stage.png | 2048x2840 のアトラス用。stage.png（2048x1176）用ではない |
| assets/effects/effect-transform.txt | assets/effects/effect.png（要検証） | 中の座標に 1024x1024 を超えるものがあり、別の大きなアトラスを指している可能性がある |

## 重複の統合（画素一致を確認済みのため、1か所だけに置いたもの）

- `skin01-guide.png` ＝ 旧 `touchLine_eff.png`（画素差 0%）
- `skin01-long.png` ＝ 旧 `longNoteLine.png`（画素差 0%）
- `skin01-notes.png` ＝ prsk-chart-viewer の `notes.png`（画素差 0%）
- `effect.png` ＝ prsk-chart-viewer の `effect/effect.png`（画素差 0%）
- `fx/profile0/` ＝ prsk-chart-viewer の `effect/*.json`（fx_lane_default.json は MD5 一致）

## 命名規則

- skin01 = Notes 01 = custom01、skin02 = Notes 02 = custom02。
- 個別ノーツPNGのファイル名は pjsekai-scores-rs の drawing.rs が参照する名前のまま。
- fx の profile0 / profile1 は、元の `effects/0/` / `effects/1/` に対応する。

## 出典

- 座標表・打撃音・ステージ画像：https://github.com/Zenzenzest/prsk-chart-viewer
- 個別ノーツPNG：https://asset3.pjsekai.moe/live/note/custom01/ および custom02/
- 描画規則の原典：https://docs.rs/pjsekai-scores-rs/latest/src/pjsekai_scores_rs/drawing.rs.html
- MikuMikuWorld：https://github.com/crash5band/MikuMikuWorld
- WebSekai：https://chartview.unipjsk.com/（現行版はクローズドソース）

## この zip に入っていないもの

コード類（エンジン、SUSパーサ、判定・入力、HUD、MP4導出、埋め込みAPI）、
フォント、2DMV動画背景、3Dキャラクター、CHUNITHM/UMIGURI素材、
楽曲ごとの SUS / BGM / ジャケットは含まれていない。
これらは素材ではなく実装・外部データのため、別途用意が必要。

## 権利

セガ／Colorful Palette 等のゲームアセットを含む。個人の開発・検証用とし、
再配布・公開利用には権利の確認が必要。
